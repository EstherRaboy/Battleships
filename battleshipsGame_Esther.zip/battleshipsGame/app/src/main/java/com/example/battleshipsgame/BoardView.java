package com.example.battleshipsgame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class BoardView extends View {
    private Board board = new Board();
    private Paint paint;
    private Paint bgPaint;
    private Context viewContext;
    private int totalClicks = 0, totalHits = 0;
    private boolean inGame = false;

    public BoardView(Context context) {
        super(context);

        viewContext = context;
        initialize();
    }

    public void initialize(){
        paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        bgPaint = new Paint();
        bgPaint.setStyle(Paint.Style.FILL);
        bgPaint.setColor(Color.rgb(255,255,255));

        board.setBorderWidth(2);
        board.setCellWidth(80);
        board.setBorderColor(Color.valueOf(Color.BLUE));
        board.setShipColor(Color.valueOf(Color.rgb(144, 101, 194)));

        totalClicks = 0;
        totalHits = 0;
        board.initialize();
        inGame = true;
    }

    public void resetBoard()
    {
        totalClicks = 0;
        totalHits = 0;
        inGame = true;

        board.resetBoard();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawPaint(this.bgPaint);
        //paint.setColor(Color.rgb(255, 0, 0));
        canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), bgPaint);
        board.paint(new Point(100,100),canvas, this.paint);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(inGame== false)
        {
            return true;
        }
        if(event.getAction() == MotionEvent.ACTION_UP) {
            Square cell = this.board.getSquare(event.getX(), event.getY());
            if(cell != null)
            {
                totalClicks++;
                cell.hit();
                if(cell.getShipIndex() > -1)
                {
                    board.hitShip(cell);
                    totalHits++;
                }
                this.invalidate();
                if(board.areAllShipsHit() == true)
                {
                    android.widget.Toast.makeText(viewContext, "Victory!", Toast.LENGTH_SHORT).show();
                    inGame = false;
                }
                else if(totalClicks > 70)
                {
                    String s= String.valueOf(totalHits)+"/"+String.valueOf(totalClicks);
                    android.widget.Toast.makeText(viewContext, "Defeat! "+s, Toast.LENGTH_SHORT).show();
                    inGame = false;
                }
            }
        }
        return true;
    }
}