package com.example.battleshipsgame;

import android.graphics.Point;

import java.lang.reflect.Array;

public class FreeSquares {
    private Square[] cells;

    public Square[] getCells() {
        return cells;
    }

    public FreeSquares(Square[] squares)
    {
        this.cells = new Square[squares.length];
        for(int i = 0; i < squares.length; i++)
        {
            this.cells[i] = squares[i];
        }
    }

    public Square findSquare(Point position)
    {
        for(int i = 0; i < this.cells.length; i++)
        {
            if(this.cells[i].getPosition().equals(position) == true)
            {
                return this.cells[i];
            }
        }
        return null;
    }

    public void removeFreeSquare(Square square)
    {
        if(this.cells != null && this.cells.length > 0)
        {
            Square[] result = new Square[this.cells.length - 1];
            int j = 0;
            for(int i = 0; i < this.cells.length && j < result.length; i++)
            {
                if(this.cells[i] != square)
                {
                    result[j] = this.cells[i];
                    j++;
                }
            }
            this.cells = result;
        }
    }


}
