package com.example.battleshipsgame;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.fonts.Font;
import android.util.Size;

import java.util.Random;

public class Board {
    private Square[] squares = null;
    private Battleship[] ships = null;
    private int[] rowHeaders = null;
    private int[] colHeaders = null;
    private int cellWidth;
    private int borderWidth;
    private Color borderColor;
    private Color cellColor;
    private Color shipColor;

    public int getCellWidth() {
        return cellWidth;
    }

    public void setCellWidth(int cellWidth) {
        this.cellWidth = cellWidth;
    }

    public int getBorderWidth() {
        return borderWidth;
    }

    public void setBorderWidth(int borderWidth) {
        this.borderWidth = borderWidth;
    }

    public Color getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(Color borderColor) {
        this.borderColor = borderColor;
    }

    public Color getCellColor() {
        return cellColor;
    }

    public void setCellColor(Color cellColor) {
        this.cellColor = cellColor;
    }

    public Color getShipColor() {
        return shipColor;
    }

    public void setShipColor(Color shipColor) {
        this.shipColor = shipColor;
    }

    public Board()
    {
        this.borderColor = Color.valueOf(Color.BLACK);
        this.cellColor = Color.valueOf(Color.CYAN);
        this.shipColor = Color.valueOf(Color.BLUE);
        this.cellWidth = 100;
        this.borderWidth = 1;

        this.squares = new Square[100];
        for(int y = 0; y < 10; y++)
        {
            for(int x = 0; x < 10; x++)
            {
                this.squares[y * 10 + x] = new Square(new Point(x, y));
            }
        }
        this.rowHeaders = new int[10];
        this.colHeaders = new int[10];
    }

    public void initialize()
    {
        this.clearBoard();
        Battleship[] ships = this.prepareShips();

        while(this.placeShips(ships) == false)
        {
        }
        for(int i = 0; i < 10; i++)
        {
            this.rowHeaders[i] = 0;
            this.colHeaders[i] = 0;
        }
        for(int s = 0; s < this.ships.length; s++)
        {
            Battleship ship = this.ships[s];
            for(int cell = 0; cell < ship.getSquares().length; cell++)
            {
                this.rowHeaders[ship.getSquares()[cell].getPosition().x]++;
                this.colHeaders[ship.getSquares()[cell].getPosition().y]++;
            }
        }
    }

    private boolean placeShips(Battleship[] battleships)
    {
        FreeSquares free = new FreeSquares(this.squares);

        Random random = new Random();
        for(int i = 0; i < battleships.length && free.getCells() != null; i++)
        {
            if(free.getCells().length == 0)
            {
                return false;
            }

            int cell = random.nextInt(free.getCells().length);
            Battleship ship = battleships[i];

            if(this.placeShip(ship, free, cell) == true)
            {
                this.ships[i] = ship;
                for(int s = 0; s < ship.getSize(); s++)
                {
                    ship.getSquares()[s].setShipIndex(i);
                }
                this.clearShipCells(ship, free);
            }
            else
            {
                return false;
            }
        }
        return true;
    }

    public void paint(Point location, Canvas graphics, Paint p)
    {
        //Paint board
        int boardSide = this.cellWidth * 10 + this.borderWidth * 11;
        Rect rBoard = new Rect(location.x, location.y, location.x + boardSide,  location.y + boardSide);
        this.repositionSquares(rBoard);

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(this.borderColor.red(), this.borderColor.green(), this.borderColor.blue()));
        graphics.drawRect(rBoard.left, rBoard.top, rBoard.right, rBoard.bottom, p);

        for(int cell = 0; cell < this.squares.length; cell++)
        {
            this.squares[cell].paint(graphics, this.cellColor, this.shipColor, this.shipColor, p);
        }

    }

    private void paintNumbers(Point location, Canvas graphics, Paint p)
    {
        p.setColor(Color.rgb(this.borderColor.red(), this.borderColor.green(), this.borderColor.blue()));
        Rect bounds = new Rect();
        p.getTextBounds("9", 0, 1, bounds);
        int textHeight = bounds.height();
        int x = location.x + this.borderWidth;
        int y = location.y - (textHeight + 8);
        p.setTextAlign(Paint.Align.CENTER);
        for(int col = 0; col < this.rowHeaders.length; col++, x += (this.cellWidth + this.borderWidth))
        {
            Rect r = new Rect(x, y, x + this.cellWidth, y + textHeight + 8);
            graphics.drawText(String.valueOf(this.rowHeaders[col]), r.left, r.top, p);
        }
        int textWidth = bounds.width();
        x = location.x - (textWidth + 8);
        y = location.y + this.borderWidth;
        for(int row = 0; row < this.colHeaders.length; row++, y += (this.cellWidth + this.borderWidth))
        {
            Rect r = new Rect(x, y, x + textWidth + 8, this.cellWidth);
            graphics.drawText(String.valueOf(this.colHeaders[row]), r.left, r.top, p);
        }
    }

    public void hitShip(Square square)
    {
        Battleship ship = this.ships[square.getShipIndex()];
        ship.hit();
    }

    private void clearBoard()
    {
        for(int cell = 0; cell < this.squares.length; cell++)
        {
            this.squares[cell].reset();
        }
        this.ships = new Battleship[10];
    }

    private void repositionSquares(Rect rBoard)
    {
        int left = rBoard.left + this.borderWidth;
        int top = rBoard.top + this.borderWidth;
        for(int y = 0; y < 10; y++)
        {
            for(int x = 0; x < 10; x++)
            {
                this.squares[y * 10 + x].setBounds(new Rect(left, top, left+ this.cellWidth, top+ this.cellWidth));
                left += (this.cellWidth + this.borderWidth);
            }
            left = rBoard.left + this.borderWidth;
            top += (this.cellWidth + this.borderWidth);
        }
    }

    private Battleship[] prepareShips()
    {
        Random rand = new Random();
        Battleship[] ships = new Battleship[10];
        boolean isVert = false;
        int i = 0;
        for(; i < 4; i++)
        {
            ships[i] = new Battleship(4);
            isVert = rand.nextInt(10) % 2 == 1;
            ships[i].setIsVertical(isVert ? true : false);
        }
        for(; i < 7; i++)
        {
            ships[i] = new Battleship(3);
            isVert = rand.nextInt(10) % 2 == 1;
            ships[i].setIsVertical(isVert ? true : false);
        }
        for(; i < 9; i++)
        {
            ships[i] = new Battleship(2);
            isVert = rand.nextInt(10) % 2 == 1;
            ships[i].setIsVertical(isVert ? true : false);
        }
        ships[9] = new Battleship(1);
        isVert = rand.nextInt(10) % 2 == 1;
        ships[9].setIsVertical(isVert ? true : false);
        return ships;
    }

    private boolean placeShip(Battleship ship, FreeSquares free, int cell)
    {
        int i = 0;
        while(i < free.getCells().length)
        {
            Square[] cells =free.getCells();
            Square head = cells[cell];
            boolean result = ship.setOnBoard(head, ship.getIsVertical(), free);
            if(result == false)
            {
                ship.setIsVertical(ship.getIsVertical() == false ? true : false);
                result = ship.setOnBoard(free.getCells()[cell], ship.getIsVertical(), free);
            }
            if(result == true)
            {
                return true;
            }
            else
            {
                ship.clearPosition();
                cell++;
                if(cell >= free.getCells().length)
                {
                    cell = 0;
                }
                i++;
            }
        }
        return false;
    }

    private void clearShipCells(Battleship ship, FreeSquares free)
    {
        Square square;
        for(int i = 0; i < ship.getSquares().length; i++)
        {
            square = ship.getSquares()[i];
            free.removeFreeSquare(square);
        }
        if(free.getCells() != null)
        {
            this.removeCellsAroundShip(ship, free);
        }
    }

    private void removeCellsAroundShip(Battleship ship, FreeSquares free)
    {
        int xStart, yStart;
        int xEnd = 0, yEnd = 0;
        int x, y;
        Square square;
        if(ship.getIsVertical() == false)
        {
            square = ship.getSquares()[0];
            y = square.getPosition().y;
            xStart = square.getPosition().x;
            if(square.getPosition().x > 0)
            {
                xStart = square.getPosition().x - 1;
                Square left = free.findSquare(new Point(xStart, square.getPosition().y));
                if(left != null)
                {
                    free.removeFreeSquare(left);
                }
            }
            if(free.getCells() != null)
            {
                square = ship.getSquares()[ship.getSquares().length - 1];
                xEnd = square.getPosition().x;
                if(square.getPosition().x < 9)
                {
                    xEnd = square.getPosition().x + 1;
                    Square right = free.findSquare(new Point(square.getPosition().x + 1, square.getPosition().y));
                    if(right != null)
                    {
                        free.removeFreeSquare(right);
                    }
                }
            }
            if(y > 0 && free.getCells() != null)
            {
                for(x = xStart; x <= xEnd && free.getCells() != null; x++)
                {
                    Square s = free.findSquare(new Point(x, y - 1));
                    if(s != null)
                    {
                        free.removeFreeSquare(s);
                    }
                }
            }
            if(y < 9 && free.getCells() != null)
            {
                for(x = xStart; x <= xEnd && free.getCells() != null; x++)
                {
                    Square s = free.findSquare(new Point(x, y + 1));
                    if(s != null)
                    {
                        free.removeFreeSquare(s);
                    }
                }
            }
        }
        else
        {
            square = ship.getSquares()[0];
            x = square.getPosition().x;
            yStart = square.getPosition().y;
            if(square.getPosition().y > 0)
            {
                yStart = square.getPosition().y - 1;
                Square top = free.findSquare(new Point(x, yStart));
                if(top != null)
                {
                    free.removeFreeSquare(top);
                }
            }
            if(free.getCells() != null)
            {
                square = ship.getSquares()[ship.getSquares().length - 1];
                yEnd = square.getPosition().y;
                if(square.getPosition().y < 9)
                {
                    yEnd = square.getPosition().y + 1;
                    Square bottom = free.findSquare(new Point(square.getPosition().x, square.getPosition().y + 1));
                    if(bottom != null)
                    {
                        free.removeFreeSquare(bottom);
                    }
                }
            }
            if(x > 0 && free.getCells() != null)
            {
                for(y = yStart; y <= yEnd && free.getCells() != null; y++)
                {
                    Square s = free.findSquare(new Point(x - 1, y));
                    if(s != null)
                    {
                        free.removeFreeSquare(s);
                    }
                }
            }
            if(x < 9 && free.getCells() != null)
            {
                for(y = yStart; y <= yEnd && free.getCells() != null; y++)
                {
                    Square s = free.findSquare(new Point(x + 1, y));
                    if(s != null)
                    {
                        free.removeFreeSquare(s);
                    }
                }
            }
        }
    }

    public Square getSquare(float x, float y)
    {
        for(int i = 0; i < this.squares.length; i++)
        {
            Square cell =this.squares[i];
            if(cell.getBounds().contains((int)x, (int)y) == true) {
                return cell;
            }
        }
        return null;
    }

    public boolean areAllShipsHit()
    {
        for(int i = 0; i < this.ships.length; i++)
        {
            Battleship ship = this.ships[i];
            if(ship.getState() != ShipState.Killed)
            {
                return false;
            }
        }
        return true;
    }

    public  void resetBoard()
    {
        for(int i = 0; i < this.squares.length; i++)
        {
            Square square = this.squares[i];
            square.resetHit();
            int index = square.getShipIndex();
            if(index > -1)
            {
                this.ships[index].resetHit();
            }
        }
    }
}

