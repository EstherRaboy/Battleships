package com.example.battleshipsgame;

public enum ShipState {
    Unknown,
    Undamaged,
    Wounded,
    Killed
}
