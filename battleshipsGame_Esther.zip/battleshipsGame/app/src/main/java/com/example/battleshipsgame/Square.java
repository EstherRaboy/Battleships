package com.example.battleshipsgame;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Region;
import android.media.VolumeShaper;

import java.util.Objects;

public class Square {
    private Point position;
    private Rect bounds;
    private boolean beenHit;
    private int shipIndex;

    public Point getPosition() {
        return position;
    }

    public Rect getBounds() {
        return bounds;
    }

    public void setBounds(Rect bounds) {
        this.bounds = bounds;
    }

    public boolean isBeenHit() {
        return beenHit;
    }

    public int getShipIndex() {
        return shipIndex;
    }

    public void setShipIndex(int index)
    {
        this.shipIndex = index;
    }

    public Square(Point pos)
    {
        this.position = pos;
        this.beenHit = false;
        this.bounds = new Rect();
        this.bounds.left = -1;
        this.bounds.top = -1;
        this.bounds.right = -1;
        this.bounds.bottom = -1;
        this.shipIndex = -1;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Square square = (Square) o;
        return position.equals(square.position);
    }

    @Override
    public int hashCode() {
        return Objects.hash(position);
    }

    public void hit()
    {
        this.beenHit = true;
    }

    public void resetHit() { this.beenHit = false; }

    public void reset()
    {
        this.beenHit = false;
        this.shipIndex = -1;
    }

    public void paint(Canvas graphics, Color backColor, Color foreColor, Color shipColor, Paint p)
    {
        Color color = backColor;
        if(this.shipIndex > -1 && this.beenHit == true)
        {
            color = shipColor;
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(color.red(), color.green(), color.blue()));
        //p.setStyle(Paint.Style.FILL);
        graphics.drawRect(this.bounds, p);

        if(this.beenHit == true)
        {
            if(this.shipIndex == -1)
            {
                int diameter = Math.min(this.bounds.width(), this.bounds.height()) / 4;
                int x = this.bounds.left + this.bounds.width() / 2;
                int y = this.bounds.top + this.bounds.height() / 2;
                p.setColor(Color.rgb(foreColor.red(), foreColor.green(), foreColor.blue()));
                float radius = diameter / 2;
                graphics.drawCircle(x, y, radius, p);
            }
            else
            {
                p.setStyle(Paint.Style.STROKE);
                p.setColor(Color.RED);
                p.setStrokeWidth(3);
                graphics.drawLine(this.bounds.left, this.bounds.top, this.bounds.right, this.bounds.bottom, p);
                graphics.drawLine(this.bounds.left, this.bounds.bottom, this.bounds.right, this.bounds.top, p);
            }
        }
    }

}
