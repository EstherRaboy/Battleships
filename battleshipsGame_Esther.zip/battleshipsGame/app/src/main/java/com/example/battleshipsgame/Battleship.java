package com.example.battleshipsgame;

import android.graphics.Point;

public class Battleship {
    private Square[] squares= null;
    private int size;
    private boolean isVertical;
    private ShipState State;

    public Square[] getSquares() {
        return this.squares != null ? this.squares : null;
    }

    public int getSize() {
        return size;
    }

    public boolean getIsVertical() {
        return isVertical;
    }

    public void setIsVertical(boolean isVertical) {
        this.isVertical = isVertical;
    }

    public ShipState getState() {
        return State;
    }

    public Battleship(int size)
    {
        this.size = size;
        this.isVertical = isVertical;
        this.State = ShipState.Unknown;
        this.squares = new Square[size];
    }

    public void clearPosition()
    {
        for(int i = 0; i < this.size; i++)
        {
            this.squares[i] = null;
        }
        this.State = ShipState.Unknown;
    }

    public boolean setOnBoard(Square head, boolean Vertical, FreeSquares free)
    {
        this.squares[0] = head;
        if(Vertical == true)
        {
            for(int i = 1; i < this.size; i++)
            {
                Square square = free.findSquare(new Point(head.getPosition().x, head.getPosition().y + i));
                if(square == null)
                {
                    return false;
                }
                this.squares[i] = square;
            }
        }
        else
        {
            for(int i = 1; i < this.size; i++)
            {
                Square square = free.findSquare(new Point(head.getPosition().x + i, head.getPosition().y));
                if(square == null)
                {
                    return false;
                }
                this.squares[i] = square;
            }
        }
        this.State = ShipState.Undamaged;
        return true;
    }

    public void hit()
    {
        this.updateState();
    }

    public void resetHit() { this.updateState(); }

    private void updateState()
    {
        int hits = 0;
        int misses = 0;
        for(int i = 0; i < this.squares.length; i++)
        {
            if(this.squares[i].isBeenHit() == true)
            {
                hits++;
            }
            else
            {
                misses++;
            }
        }
        if(hits == this.size)
        {
            this.State = ShipState.Killed;
        }
        else if(misses == this.size)
        {
            this.State = ShipState.Undamaged;
        }
        else if(hits > 0 && misses > 0)
        {
            this.State = ShipState.Wounded;
        }
    }

}
