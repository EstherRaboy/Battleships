package com.example.battleshipsgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

public class BoardActivity extends AppCompatActivity {
    public BoardView boardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board);

        boardView = new BoardView(this);
        FrameLayout frame = findViewById(R.id.frm);
        frame.addView(boardView);
    }

    public void onRetry(View v) {
        boardView.resetBoard();
        boardView.invalidate();
    }
    public void onNewGame(View v){
        boardView.initialize();
        boardView.invalidate();
    }
}